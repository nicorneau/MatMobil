#' Fonctions pour le calcul de matrices de transition et d'indices de mobilité
#' 
#' MatMobil fournit des outils permettant le calcul de matrice de transition et
#' d'indices de mobilité (et d'immobilité).
#' 
#' @docType package
#' @name MatMobil-package
#' @aliases MatMobil
NULL
