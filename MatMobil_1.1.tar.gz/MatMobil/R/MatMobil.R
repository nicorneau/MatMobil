#' Fonctions pour le calcul de matrices de transition et d'indices de mobilite
#' 
#' MatMobil fournit des outils permettant le calcul de matrice de transition et
#' d'indices de mobilite (et d'immobilite)
#' 
#' @docType package
#' @name MatMobil-package
#' @aliases MatMobil
NULL
